import pandas as pd
import sys
import networkx as nx
import csv
import matplotlib.pyplot as plt
import random
from random import choice
import numpy as np
filename = sys.argv[1]
G=nx.Graph()
nodes_data={}
n_color={}
def cr_grph():
        df = pd.read_csv('roadShort.txt', sep="\t", header=None, names=["From", "To"])
        #print("Data Frame:")
        #print((df))
        r = None
        for i, r in df.iterrows(): 
              nodes_data[i]=(r['From'])
        with open(filename, 'r') as dfile:
              reader=csv.reader(dfile)
              edge_data = list(reader)
        for n in edge_data:
              n_color[n[0]]='black'
        G.add_edges_from(edge_data)
        print("Number_of_Nodes",G.number_of_nodes())
        print(nx.info(G))
        return (G,edge_data)
cr_grph()