import pandas as pd
import sys
filename = sys.argv[1]
df = pd.read_csv(filename, sep="\t", header=None)
df.to_csv("roadShortCSV.csv", index=False, encoding='utf8')