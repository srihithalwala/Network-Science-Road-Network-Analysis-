import numpy as np
import plotly.plotly as py
import pandas as pd
import matplotlib.pyplot as plt
x = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20']
y = [4,15,90,2,6,11,20,37,3,31,94,22,17,2,4,3,2,4,3,2]
y2=[2,1,10,12,0,1,12,13,4,3,9,10,8,9,5,1,3,7,9,21]
y3=[5,12,3,14,5,11,2,10,9,8,0,16,1,18,3,13,4,5,12,2]
y4=[11,6,9,6,12,8,44,53,4,13,4,5,8,7,0,16,19,9,13,8]
plt.plot(x, y , marker='.')#Closeness
plt.plot(x,y2,marker='.')#bet
plt.plot(x,y3,marker='.')#degree
plt.plot(x,y4,marker='.')#eigen
#plt.title('nodes effected for each iteration centrality', fontsize=10)
plt.xlabel('Iterations', fontsize=14)
plt.ylabel('number of nodes effected based on centrality', fontsize=14)
plt.legend(['Closeness', 'Betweenness', 'Degree', 'Eigen'], loc='upper right')
plt.show()