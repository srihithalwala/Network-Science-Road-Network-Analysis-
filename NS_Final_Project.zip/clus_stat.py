import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("clus_dict_rec.csv", header=None, sep=",")
plt.scatter(df[0], df[1], s=1, marker="*")
plt.title('title', fontsize=10)
plt.xlabel('Number of nodes', fontsize=14)
plt.ylabel('Clustering coefficient', fontsize=14)
#plt.savefig('fname.png')
plt.show()