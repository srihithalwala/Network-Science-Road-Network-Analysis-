import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("bc_dict_rec.csv", header=None)
plt.scatter(df[0], df[1], s=1)
plt.xlabel('Number of nodes', fontsize=14)
plt.ylabel('Betweenness centrality', fontsize=14)
#plt.savefig('fname.png')
plt.show()