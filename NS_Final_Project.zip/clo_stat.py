import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("closeness_dict_rec.csv", header = None)
plt.scatter(df[0], df[1])
plt.title('title', fontsize=10)
plt.xlabel('Number of nodes', fontsize=14)
plt.ylabel('Closeness centrality', fontsize=14)
#plt.savefig('fname.png')
plt.show()